from psonic import *

play(70)
sleep (0.25)
play(chord(E4,MINOR))
sleep (0.25)
